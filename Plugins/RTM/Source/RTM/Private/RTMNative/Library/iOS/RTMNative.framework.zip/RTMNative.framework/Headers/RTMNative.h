//
//  RTMNative.h
//  RTMNative
//
//  Created by Sun on 2022/1/14.
//

#import <Foundation/Foundation.h>

//! Project version number for RTMNative.
FOUNDATION_EXPORT double RTMNativeVersionNumber;

//! Project version string for RTMNative.
FOUNDATION_EXPORT const unsigned char RTMNativeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RTMNative/PublicHeader.h>
